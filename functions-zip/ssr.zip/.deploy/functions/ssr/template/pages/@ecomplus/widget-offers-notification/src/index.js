export default options => {
  console.log('Offers notification widget started with EJS appends')
}
